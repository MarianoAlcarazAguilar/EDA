package Tests;

import Trees.*;
import java.util.Iterator;
import java.util.Random;

public class Tests {

    public static void main(String[] args) {
        
        
        BinaryTree<Integer> tree = new BinaryTree<>();
        Random r = new Random();
        int aux;
        
        for(int i = 0; i < 1000; i++){
            aux = r.nextInt(1000);
            tree.insert(aux);
        }

        Iterator<Integer> iteInOrder = tree.iteratorInOrder();
        while(iteInOrder.hasNext())
            System.out.print(iteInOrder.next() + " ");


        
        System.out.println("\n" + tree.getRoot().getElement());
        System.out.println(tree.contains(tree.getRoot().getElement()+1));
        

    }

}
