package Tests;

public class HashTests {

    public static void main(String[] args) {
        
        
        
        
        
    }

}
