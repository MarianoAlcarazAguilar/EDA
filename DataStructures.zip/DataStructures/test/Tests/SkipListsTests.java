package Tests;

import SkipLists.SkipList;
import SkipLists.SkipListAux;

public class SkipListsTests {

    public static void main(String[] args) {
        /*
        SkipList<Integer> list = new SkipList<>();
        
        Integer[] nums = {1,2,3,4,5};
        for(Integer num: nums){
            list.insert(num);
        }
        
        System.out.println(list);
        System.out.println(list.printSecondLevel());
        */
        /*
        SkipListAux<Integer> otherList = new SkipListAux<>();
        for(Integer num: nums){
            otherList.insert(num);
        }
        
        
        System.out.println(otherList);
        */
        
        SkipListAux<Integer> lista = new SkipListAux<>();
        Integer[] nums = {1,2,3,4,5,6,7,8,9,10};
        //lista.changeSeed(188199);
        for(Integer num: nums){
            lista.insert(num);
        }
        //System.out.println(lista);
        
    }

}
