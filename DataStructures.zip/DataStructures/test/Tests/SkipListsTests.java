package Tests;

import SkipLists.SkipList;
import java.util.Random;

public class SkipListsTests {

    public static void main(String[] args) {
        
         Random r = new Random();
        SkipList<Integer> lista = new SkipList<>();
        Integer[] nums = {1,2,3,4,5,6,7,8,9,10, -1};
        
        for(Integer num: nums){
            lista.insert(num);
        }
        
         System.out.println(lista.printAllLists());
         System.out.println("Total de listas: " + lista.getTotalLists());
         System.out.println("Máximo de listas permitidas: " + lista.getLogN() );
        
         
         
         for(Integer num: nums){
              lista.delete(num);
              System.out.println("");
              System.out.println(lista.printAllLists());
              System.out.println("Total de listas: " + lista.getTotalLists());
              System.out.println("Máximo de listas permitidas: " + lista.getLogN() );
         }
         
         lista.insert(1);
         lista.insert(2);
         lista.insert(-3);
         
         
         System.out.println("");
         System.out.println(lista.printAllLists());
         System.out.println("Total de listas: " + lista.getTotalLists());
         System.out.println("Máximo de listas permitidas: " + lista.getLogN() );
    }

}
