package Tests;

import Trees.*;

public class TreesTests {

    public static void main(String[] args) {
        AVLTree<Integer> tree = new AVLTree<>();
        
        
        
  
        
        Integer[] nums = {30,2,0,100,90,40,-100,20,1,-110,10};
        
        for(Integer i: nums){
            tree.insert(i);
        }
        System.out.println("Previo a eliminar:");
        System.out.println(tree.printLevelOrder());
        
        tree.delete(2);
        tree.delete(10);
        
        System.out.println("Tras eliminación:");
        System.out.println(tree.printLevelOrder());
       
            
    }

    

    

}
