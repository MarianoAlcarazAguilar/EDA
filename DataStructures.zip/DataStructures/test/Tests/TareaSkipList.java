package Tests;

import SkipLists.SkipList;
import java.util.Random;

public class TareaSkipList {

    public static void main(String[] args) {
        
         SkipList<Integer> lista = new SkipList<>();
         Random rand = new Random();
         long[] resultadosInsert = new long[10];
         long[] resultadosDelete = new long[10];
         long[] resultadosSearch = new long[10];
         Integer[] tamanos = {1000, 2000,3000,4000,5000,6000,7000,8000,9000,10000};
        int resp = 0;
         
         for(Integer size: tamanos){
              //Cuánto tarda en insertar size elementos
             long start = System.currentTimeMillis();
             for(int i = 0; i <  size; i++){
                  lista.insert(rand.nextInt());
             }
             long end = System.currentTimeMillis();
             long total = end - start;
             resultadosInsert[resp] = total;

             //Cuánto tarda en borrar size elementos
             start = System.currentTimeMillis();
             for(int i = 0; i < size; i++){
                  lista.delete(rand.nextInt());
             }
             end = System.currentTimeMillis();
             total = end - start;
             resultadosDelete[resp] = total;

             //Cuánto tarda en buscar size elementos
             start = System.currentTimeMillis();
             for(int i = 0; i < size; i++){
                  lista.contains(rand.nextInt());
             }
             end = System.currentTimeMillis();
             total = end - start;
             resultadosSearch[resp] = total;
             resp++;
         }
         
         //Tiempos de inserción
         System.out.println("Tiempos de inserción\n");
         for(int i = 0; i < tamanos.length; i++){
              System.out.println(tamanos[i] + ""+ resultadosInsert[i]);
         }
         
         //Tiempos de eliminar
         System.out.println("Tiempos de borrado\n");
         for(int i = 0; i < tamanos.length; i++){
              System.out.println(tamanos[i] + "" +resultadosDelete[i]);
         }
         
         //Tiempos de búsqueda
         System.out.println("Tiempos de búsqueda\n");
         for(int i = 0; i < tamanos.length; i++){
              System.out.println(tamanos[i] + "" +resultadosSearch[i]);
         }
        
        
        
        
        
    }
        
        
    
}
    

