package Tests;

import Heaps.Heap;

public class HeapTests {

    public static void main(String[] args) {
        
        Heap<Integer> heap = new Heap<>();
        
        Integer[] nums = {50, 60, 100, 200, 400, 1000, 5000, 300, -1};
        
        for(Integer i: nums){
            heap.insert(i);
        }
        
        System.out.println(heap);
        
        heap.deleteMin();
        
        System.out.println(heap);
        
        
    }
    
    
}
