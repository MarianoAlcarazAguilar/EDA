package Tests;

public class CompetitiveProgramming {
    
    //Dado un arreglo de enteros y un entero regresar las posiciones del arreglo que sumadas dan el entero.
    //Suponemos que solo se necesitan 2 elementos para completar la suma
    public static int[] getIndex(int[] array, int target){
        //Estoy pensando en hacer combinaciones
        int totElem = array.length;
        int suma;
        int[] resp = new int[2];
        for(int i = 0; i < totElem; i++){
            if(array[i] > target)
                i++;
            for(int j = i; j < totElem; j++){
                suma = array[i] + array[j];
                if(suma == target){
                    resp[0] = i;
                    resp[1] = j;
                    break;
                }
            }
        }
        return resp;
    }

    public static void main(String[] args) {
        int[] array = {6,1,2,3,4};
        int target = 9;
        int[] resp = getIndex(array, target);
        System.out.println(resp[0]);
        System.out.println(resp[1]);
        
        

    }

}
