package Sets;
import java.util.Iterator;
import java.util.Random;
import ADTsException.*;
import LinkedStructures.*;

public class LnkdStrcSet<T> implements SetADT<T>, Iterable<T> {
    // Atributes
    private LinkedStruct<T> set; 
    

    /**
    * Creates an empty set.
    */
    public LnkdStrcSet() {
        set = new LinkedStruct();
    }


    /**
    * Returns true if this set is empty and false otherwise.
    */
    public boolean isEmpty() {
        return set.isEmpty();
    }

    /**
    * Returns the number of elements currently in this set.
     * @return 
    */
    public int size() {
        return set.size();
    }
    
    /**
    * Returns true if this set contains the specified element.
     * @param element
     * @return 
    */
    public boolean contains (T element) {
        if(element == null)
            throw new RuntimeException("element in contains is null");
        
        boolean found = false;
        Iterator it = set.iterator();
        while(it.hasNext() && !found){
            if(it.next().equals(element))
                found = true;
        }
        return found;
    }    
    
    /**
    * Adds the specified element to the set if it is not already
    * present.
     * @param element
    */
    public void add(T element) {
        if (element == null)
            throw new RuntimeException("element in add is null");
        
        if(!contains(element)){
            set.add(element, set.size() + 1);
        }
    }

    /**
    * Returns an iterator for the elements currently in this set.
     * @return 
    */
    public Iterator<T> iterator() {
        return set.iterator(); 
    }

    /**
    * Returns a string representation of this set.
     * @return 
    */
    public String toString() {
        String result = "";
        if(isEmpty()) {
            result = "LnkdStrcSet is {EMPTY";
        } else {
            result = "LnkdStrcSet{ ";
            result= result + set.toString() + " ";
        }
        result = result + "}";
        return result;
    }    
    
    // EL RESTO DE LOS METODOS NO SE PROGRAMA, además estan vacios.
    /**
    * Adds the contents of otherSet to this set.
     * @param oSet
    */
    public void addAll(SetADT<T> oSet) throws ADTsException {
        // NO SE PROGRAMA
    }

    /**
    * Removes a random element from the set and returns it. Throws
    * an EmptyCollectionException if the set is empty.
     * @return 
    */
    public T removeRandom() throws ADTsException {
        // NO SE PROGRAMA
        return null;
    }

    /**
    * Removes the specified element from the set and returns it.
    * Throws an EmptyCollectionException if the set is empty and a
    * ElementNotFoundException if the element is not in the set.
     * @param element
     * @return 
    */
    public T remove (T element) throws ADTsException {
        // NO SE PROGRAMA
        return null;
    }

    /**
    * Returns a new set that is the union of this set and
    * otherSet.
    */
    public SetADT<T> union (SetADT<T> oSet) throws ADTsException {
        // NO SE PROGRAMA
        return null;
    }

    /** Returns the intersection of this set and the otherSet.
    */
    public SetADT<T> intersection(SetADT<T> oSet) throws ADTsException {
        // NO SE PROGRAMA
        return null;
    }

    /** Returns the difference of this set and the otherSet.
    */
    public SetADT<T> difference(SetADT<T> oSet) throws ADTsException {
        // NO SE PROGRAMA
        return null;
    }


    /**
    * Returns true if this set contains exactly the same elements
    * as the otherSet.
    */
    public boolean equals (SetADT<T> oSet) throws ADTsException {
        // NO SE PROGRAMA
        return false;
    }

}


