package HashTables;

public class HashTable<T extends Hashable<T>> {
    
    private int cont;
    private HashNode<T>[] list;
    private float loadFactor;
    private static int MAX;
    
    public HashTable(){
        cont = 0;
        MAX = 100;
        loadFactor = (float) 0.8;
        list = (HashNode<T>[]) (T[]) new Object[MAX];
    }
    
    private HashNode<T> find(T element){
        HashNode<T> searched = new HashNode(element);
        long key = searched.getKey();
        int pos = (int) (key % MAX);
        
        HashNode<T> aux = list[pos];
        //Aquí aux puede ser nulo si no hay nada.
        // Creo que podemos omitir este paso.
        if(aux == null){
            return aux;
        }
        // Aquí aux NO es null. Entonces está en algun lugar por aquí.
        while(aux != null && !aux.getElement().equals(element)){
            aux = aux.getNext();
        }
        return aux;
    }
    
    public void insert(T element){
        
        // Esta madre está mal
        
        
        if(element == null)
            return;
        
        HashNode<T> toInsert = new HashNode(element);
        long key = toInsert.getKey(); 
        int pos = (int) (key % MAX);
        cont++;
        
        // Aquí falta ver si hay que expandir
        if(cont/MAX > loadFactor)
            expand();
        
        HashNode<T> aux = list[pos];
        list[pos] = toInsert;
        toInsert.setNext(aux);
        
        
        
    }
    
    private void expand(){
        int NEWMAX = 2*MAX;
        HashNode<T>[] newList = (HashNode<T>[]) (T[]) new Object[NEWMAX];
        long key;
        int newPos;
        HashNode<T> aux, aux2;
        
        for(int i = 0; i < MAX; i++){
            aux = list[i];
            while(aux != null){
                key = aux.getKey();
                newPos = (int) (key % NEWMAX);
                aux2 = newList[newPos];
                newList[newPos] = aux;
                aux.setNext(aux2);
                aux = aux.getNext();
            }
        }
        
        list = newList;
        MAX = NEWMAX;
    }
    
    public void delete(T element){
        //Hay que revisar que esto esté bien
        HashNode<T> node = this.find(element);
        
        if(node == null)
            return;
        
        long key = node.getKey();
        int pos = (int) key % MAX;
        
        HashNode<T> aux = this.list[pos];
        
        if(aux.getElement().equals(element)){
            list[pos] = aux.getNext();
        } else {
            while(!aux.getNext().getElement().equals(element)){
                aux = aux.getNext();
            }
            aux.setNext(node.getNext());
        }
        cont--;
    }
    
    
    
}
