package HashTables;

public class HashNode<T extends Hashable<T>> {
    
    private T element;
    private long key;
    private HashNode<T> next;
    
    
    public HashNode(){
        element = null;
        next = null;
        key = -1;
    }
    
    public HashNode(T element){
        this.element = element;
        next = null;
        this.key = element.getHash(); 
    }

    public T getElement() {
        return element;
    }

    public HashNode<T> getNext() {
        return next;
    }
    
    public long getKey(){
        return key;
    }

    public void setElement(T element) {
        this.element = element;
    }

    public void setNext(HashNode<T> next) {
        this.next = next;
    }
    
    
    
   
    
    

}
