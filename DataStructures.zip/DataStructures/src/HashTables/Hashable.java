package HashTables;

public interface Hashable<T> {
    
    // TODO: programar la función hash que regrese su llave
    public long getHash();
    
    
    
}
