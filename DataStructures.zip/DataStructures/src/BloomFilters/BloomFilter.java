package BloomFilters;


/**
 * Operaciones disponibles:
 *      -Insertar
 *      -Buscar
 * 
 * Ventajas:
 *      -Rapidez
 *      -Eficiencia en espacio
 * 
 * Básicamente es una HashTable de booleanos
 * 
 * @author Mariano Alcaraz Aguilar
 */
public class BloomFilter {

}
