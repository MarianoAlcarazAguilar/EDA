package SkipLists;

import java.util.Random;

public class SkipListAux<T extends Comparable <T>> {
    
    private SkipNode<T> head;
    private SkipNode<T> tail;
    private int cont;
    private int nLists;
    private static final Random R = new Random();
    
    public SkipListAux(){
        head = new SkipNode<>();
        tail = new SkipNode<>();
        this.linkLR(head, tail);
        cont = 0;
        nLists = 1;
        R.setSeed(188192);
    }
    
    //Insertar
    public void insert(T element){
        SkipNode<T> actual = find(element);
        SkipNode<T> nuevo = new SkipNode<>(element);
        SkipNode<T> aux;
        int flips = 1;
        int maxLevels = getLogN();
        double generated = R.nextDouble();
        
        //Primero lo metemos donde debe de ir
        insertHorizontal(actual, nuevo);
        cont++;
        
        
        //Ahora vemos si debemos insertarlo también arriba
        while(flips <= maxLevels && generated > 0.5){
            if(nLists < flips)
                expand();
            
            while(actual.getUp() == null){
                actual = actual.getLeft();
            }
            
            actual = actual.getUp();
            aux = new SkipNode<>(element);
            
            this.insertHorizontal(actual, aux);
            this.linkUD(nuevo, aux);
            nuevo = aux;
            
            flips++;
            generated = R.nextDouble();
        }
    }
    
    
    //Buscar
    public SkipNode<T> find(T element){
        SkipNode<T> actual = head;
        boolean flag = false;
        while(!flag){
            while(actual.getRight().getElement() != null && element.compareTo(actual.getRight().getElement())> 0)
                actual = actual.getRight();
            if(actual.getDown() != null){
                actual = actual.getDown();
            } else {
                flag = true;
            }
        }
        return actual;
    }
    
    
    //Borrar
    
    
    //Imprimir
    public String toString(){
        SkipNode<T> aux = head;
        StringBuilder sb = new StringBuilder();
        
        while(aux.getRight() != null && aux.getRight().getElement() != null){
            sb.append(aux.getRight().getElement());
            sb.append(" ");
            aux = aux.getRight();
        }
        
        return sb.toString();
    }
    
    
    //Métodos auxiliares
    
    private void linkLR(SkipNode<T> left, SkipNode<T> right){
        if(left == null || right == null)
            return;
        left.setRight(right);
        right.setLeft(left);
    }
    
    private void linkUD(SkipNode<T> up, SkipNode<T> down){
        if(up == null || down == null)
            return;
        up.setDown(down);
        down.setUp(up);
    }
    
    private void insertHorizontal(SkipNode<T> prev, SkipNode<T> nuevo){
        SkipNode<T> aux = prev.getRight();
        linkLR(prev, nuevo);
        linkLR(nuevo, aux);
    }
    
    private void expand(){
        SkipNode<T> newHead = new SkipNode<>();
        SkipNode<T> newTail = new SkipNode<>();
        
        this.linkLR(newHead, newTail);
        this.linkUD(newHead, head);
        this.linkUD(newTail, tail);
        head = newHead;
        tail = newTail;
        //??linkLR(head, tail)
        nLists++;
    }
    
    private int getLogN(){
        return (int) Math.ceil(Math.log(cont)/Math.log(2));
    }
    
    public void changeSeed(int seed){
        R.setSeed(seed);
    }
    
    

}
