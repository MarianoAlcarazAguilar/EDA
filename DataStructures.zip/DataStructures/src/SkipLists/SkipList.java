package SkipLists;

import java.util.Random;

public class SkipList<T extends Comparable<T>> {
    
    private SkipNode<T> head;
    private SkipNode<T> tail;
    private int cont;
    private int nLists;
    private Random r;
    
    public SkipList(){
        head = new SkipNode<>();
        tail = new SkipNode<>();
        r = new Random();
        r.setSeed(188192);
        cont = 0;
        nLists = 1;
        head.setRight(tail);
        tail.setLeft(head);
    }
    
    public SkipList(T element){
        this();
        SkipNode<T> node = new SkipNode(element);
        head.setRight(node);
        node.setRight(tail);
        node.setLeft(head);
        tail.setLeft(node);
        cont++;
    }
    
    public int getTotalLists(){
         return this.nLists;
    }
    
    public int size(){
         return cont;
    }
    
    @Override
    public String toString(){
        SkipNode<T> aux = head;
        StringBuilder sb = new StringBuilder();
        
        while(aux.getDown() != null){
            aux = aux.getDown();
        }
        
        while(aux.getRight() != null && aux.getRight().getElement() != null){
            sb.append(aux.getRight().getElement());
            sb.append(" ");
            aux = aux.getRight();
        }
        
        return sb.toString();
    }
    
    
    
    /**
     * Este método regresa un booleano confirmando si element está o no en la skip list.
     * @param element
     * @return 
     */
    public boolean contains(T element){
         SkipNode<T> aux = find(element);
         boolean resp;
         
         //Usamos un try catch porque si buscamos un elemento más grande al mayor en la lista y no está
         //Entonces aux.getRight.getElement es nulo y ahí se rompería
         
         try{
              resp = aux.getRight().getElement().equals(element);
         } catch (Exception e){
              resp = false;
         }
         return resp;
    }
    
    /**
     * Ya arreglé esta chingadera
     * @param element 
     */
    public void insert(T element){
        SkipNode<T> previous = find(element);
        SkipNode<T> toInsert = new SkipNode<>(element);
        cont++;
        
        //Primero lo insertamos
        this.connect(previous, toInsert, previous.getRight());
        
        //Luego aventamos la moneda para ver si lo mandamos arriba o no
        SkipNode<T> aux = toInsert;
        int maxLevels = this.getLogN();
        int i = 0;
        double generated = r.nextDouble();
        
        //Repetimos mientras la moneda nos diga que sigamos y aún no rebasemos el total máximo de listas permitidas
        while(generated > 0.5 && i  <=maxLevels){
             
            //Hacemos un nuevo nodo
            SkipNode<T> newAbove = new SkipNode<>(element);
            
            //Encontramos el nodo más próximo con un nodo arriba.
            SkipNode<T> nextWithAbove = findNextAbove(aux);
            
            //Conectamos los nodos de la lista superior
            connect(nextWithAbove.getUp(), newAbove, nextWithAbove.getUp().getRight());
            
            //Conectamos el nodo de arriba con el de abajo
            newAbove.setDown(aux);
            aux.setUp(newAbove);
            
            //Dejamos todo listo para la siguiente repetición
            aux = newAbove;
            generated = r.nextDouble();
            i++;
        }
    }
    
    /**
     * Este método elimina element
     * Si element no se encuentra en la skip list entonces no hace nada.
     * @param element 
     */
    public void delete(T element){
         //Primero vemos si está en la skip list o no
         if(!contains(element))
              return;
         
         //Aquí ya sabemos que el elemento sí está.
         SkipNode<T> eliminar = find(element).getRight();
         
         //Primero lo borramos de la lista de hasta abajo
         SkipNode<T> left = eliminar.getLeft();
         SkipNode<T> right = eliminar.getRight();
         
         left.setRight(right);
         right.setLeft(left);
         
         //Ahora lo eliminamos de todas las listas superiores
         eliminar = eliminar.getUp();
         while(eliminar != null){
              left = eliminar.getLeft();
              right = eliminar.getRight();
              
              left.setRight(right);
              right.setLeft(left);
              
              eliminar = eliminar.getUp();
         }
         cont--;
         
         //Ahora tenemos que revisar que aún estemos en la cantidad correcta de listas.
         checkAmountLists();
    }
    
    
    //                                              ------------------------MÉTODOS AUXILIARES------------------------------
    
    /**
     * MÉTODO AUXILIAR
     * Este método recibe un elemento y regresa el nodo previo a este.
     * Si el nodo con el elemento buscado NO está, no importa. 
     * Entonces regresa el nodo previo a la posición correcta donde element debería de estar
     * @param element
     * @return 
     */
    private SkipNode<T> find(T element){
        SkipNode<T> actual = head;
        boolean done= false;
        while(!done){
            while(actual.getRight().getElement() != null && element.compareTo(actual.getRight().getElement())> 0)
                actual = actual.getRight();
            if(actual.getDown() != null){
                actual = actual.getDown();
            } else {
                done = true;
            }
        }
        return actual;
    }
    
    /**
     * MÉTODO AUXILIAR
     * Funcionamiento: CORRECTO
     * Este método recibe 3 nodos.
     * Uno izquierdo, uno de en medio y uno derecho.
     * Los une.
     * @param left
     * @param center
     * @param right 
     */
    private void connect(SkipNode<T> left, SkipNode<T> center, SkipNode<T> right){
        left.setRight(center);
        center.setRight(right);
        center.setLeft(left);
        right.setLeft(center);
    }
    
    /**
     * MÉTODO AUXILIAR
     * Funcionamiento: CORRECTO
     * Este método recibe un nodo y regresa el nodo más próximo que tenga up distino de nulo.
     * En caso de llegar a la cabeza y no encontrar ninguno genera un nuevo nivel automáticamente.
     * En el peor de los casos regresa la cabeza anterior pues ya tendría un nivel arriba de ella.
     * @param node
     * @return 
     */
    private SkipNode<T> findNextAbove(SkipNode<T> node){
         /*
         Notas mentales:
         Me dan un nodo. 
         Quiero encontrar el nodo más próximo con uno arriba.
         En caso de que llegue a la cabeza tengo que crear una nueva lista.
         */
         SkipNode<T> aux = node;
         while(aux.getLeft() != null){
              if(aux.getLeft().getUp() != null){
                   return aux.getLeft();
              }     
              aux = aux.getLeft();
         }
         
         /*
         Si aquí no me he salido es porque aux.getLeft fue nulo y no encontró ninguno que tuviera arriba.
         Significa que estoy en LA cabeza.
         Hay que agregar un nuevo nivel y regresar la cabeza ANTERIOR.
         */
         
         //Creamos nuevo nivel
         SkipNode<T> newHead = new SkipNode<>();
         SkipNode<T> newTail = new SkipNode<>();
         
         SkipNode<T> oldHead = head;
         SkipNode<T> oldTail = tail;
         
         //Conectamos los nuevos nodos entre sí
         newHead.setRight(newTail);
         newTail.setLeft(newHead);
         
         //Conectamos las cabezas
         newHead.setDown(oldHead);
         oldHead.setUp(newHead);
         
         //Conectamos las colas
         newTail.setDown(oldTail);
         oldTail.setUp(newTail);
         
         //Cambiamos head y tail por los nuevos.
         head = newHead;
         tail = newTail;
         
         //Aumentamos el total de listas
         nLists++;
         
         //Regresamos la cabeza anterior
         return head.getDown();
    }
    
   
    /**
     * MÉTODO AUXILIAR
     * Funcionamiento: CORRECTO
     * @return el número máximo de listas permitidas dada la cantidad de elementos.
     */
    public int getLogN(){
        int max = (int) Math.ceil(Math.log(cont)/Math.log(2));
        return max+1;
    }
    
    
    
    /**
     * MÉTODO AUXILIAR
     * Imprime todas las listas en orden.
     * Se usó para probar el correcto funcionamiento de la implementación.
     * @return 
     */
    public String printAllLists(){
         
         SkipNode<T> aux = head;
         StringBuilder sb = new StringBuilder();
         
         while(aux != null){
              SkipNode<T> subAux = aux;
              while(subAux.getRight() != null && subAux.getRight().getElement() != null){
                   sb.append(subAux.getRight().getElement());
                   sb.append(" ");
                   subAux = subAux.getRight();
              }
              sb.append("\n");
              
              aux = aux.getDown();
         }
         
         return sb.toString();
    }
    
    /**
     * MÉTODO AUXILIAR
     * Cambia la semilla inicial para probar el correcto funcionamiento de la implementación.
     * @param newSeed 
     */
    public void changeSeed(long newSeed){
         this.r.setSeed(newSeed);
    }

    
    /**
     * MÉTODO AUXILIAR
     * Este método revisa que la cantidad de listas sea la adecuada.
     * En caso de ser mayor a la permitida elimina la lista superior.
     * En caso de que la lista esté vacía la elimina
     */
    private void checkAmountLists() {
          int maxLevels = this.getLogN();
          if(nLists > maxLevels){
               deleteTop();
               
               while(topIsEmpty()){
                    deleteTop();
               }
          }
     }
    
    /**
     * MÉTODO AUXLIAR
     * Si el contador es distinto de cero entoces revisa que las listas superiores no estén vacías.
     * Si el contador es cero entonces regresa false para evitar errores en otros métodos.
     * @return 
     */
    private boolean topIsEmpty(){
         if(cont != 0)
              return head.getRight().equals(tail) && tail.getLeft().equals(head);
         else
              return false;
    }
    
    /**
     * MÉTODO AUXILIAR
     * Elimina la lista de hasta arriba.
     * 
     * ADVERTENCIA:
     *    Este método se usa en conjunto con topIsEmpty.
     *    En caso contrario puede perder información.
     */
    private void deleteTop(){
         SkipNode<T> newHead = head.getDown();
         SkipNode<T> newTail = tail.getDown();
         
         if(newHead == null || newTail == null)
              return;
         
         SkipNode<T> aux = newHead;
         while(aux != null){
              aux.setUp(null);
              aux = aux.getRight();
         }
         
         head = newHead;
         tail = newTail;
         
         nLists--;
    }

}
