package SkipLists;

import java.util.Random;

public class SkipList<T extends Comparable<T>> {
    
    private SkipNode<T> head;
    private SkipNode<T> tail;
    private int cont;
    private int nLists;
    
    public SkipList(){
        head = new SkipNode<>();
        tail = new SkipNode<>();
        cont = 0;
        nLists = 1;
        head.setRight(tail);
        tail.setLeft(head);
    }
    
    public SkipList(T element){
        this();
        SkipNode<T> node = new SkipNode(element);
        head.setRight(node);
        node.setRight(tail);
        node.setLeft(head);
        tail.setLeft(node);
        cont++;
    }
    
    public SkipNode<T> find(T element){
        SkipNode<T> actual = head;
        boolean flag = false;
        while(!flag){
            while(actual.getRight().getElement() != null && element.compareTo(actual.getRight().getElement())> 0)
                actual = actual.getRight();
            if(actual.getDown() != null){
                actual = actual.getDown();
            } else {
                flag = true;
            }
            
        }
        return actual;
    }
    
    public void insert(T element){
        SkipNode<T> previous = find(element);
        SkipNode<T> toInsert = new SkipNode<>(element);
        
        //Primero lo insertamos
        this.connect(previous, toInsert, previous.getRight());
        
        //Luego aventamos la moneda para ver si lo mandamos arriba o no
        int maxLevels = this.getLogN();
        int i = 0;
        Random r = new Random();
        r.setSeed(188192);
        double generated = r.nextDouble();
        SkipNode<T> aux = toInsert;
        
        while(generated < 0.5 && i < maxLevels){
            //Hacemos un nuevo nodo
            SkipNode<T> newAbove = new SkipNode<>(element);
            SkipNode<T> nextAbove = findNextAbove(aux);
            this.connect(nextAbove, newAbove, nextAbove.getRight());
            newAbove.setDown(aux);
            aux.setUp(newAbove);
            aux = newAbove;
            generated = r.nextDouble();
            i++;
        }
    }
    
    private void connect(SkipNode<T> left, SkipNode<T> center, SkipNode<T> right){
        left.setRight(center);
        center.setRight(right);
        center.setLeft(left);
        right.setLeft(center);
    }
    
    private SkipNode<T> findNextAbove(SkipNode<T> node){
        SkipNode<T> aux = node.getLeft();
        SkipNode<T> other = aux;
        SkipNode<T> above = null;
        
        while(aux != null){
            other = aux;
            if(aux.getUp() != null){
                above = aux.getUp();
            }
            aux = aux.getLeft();
        }
        
        if(aux != null){
            //Si aux es distinto de null significa que me salí porque encontré uno que tiene above
            return above;
        } else {
            //Si aux es null significa que me salí porque estoy en una cabeza.
            //La cabeza se quedó guardad en other
            //Si other tiene arriba entonces tengo que mandar ese
            if(other.getUp() != null)
                return other.getUp();
            //Si other no tiene arriba entonces other es la cabeza.
            //Hay que crear un nuevo nivel
            SkipNode<T> newHead = new SkipNode<>();
            SkipNode<T> newTail = new SkipNode<>();
            newHead.setDown(head);
            newTail.setDown(tail);
            newHead.setRight(newTail);
            newTail.setLeft(newHead);
            head.setUp(newHead);
            tail.setUp(newTail);
            head = newHead;
            tail = newTail;
            nLists++;
            return head;
        }
    }
    
    public int getLogN(){
        return (int) Math.ceil(Math.log(cont)/Math.log(2));
    }
    
    
    public String toString(){
        SkipNode<T> aux = head;
        StringBuilder sb = new StringBuilder();
        
        while(aux.getDown() != null){
            aux = aux.getDown();
        }
        
        while(aux.getRight() != null && aux.getRight().getElement() != null){
            sb.append(aux.getRight().getElement());
            sb.append(" ");
            aux = aux.getRight();
        }
        
        return sb.toString();
    }
    
    public String printAllLists(){
        SkipNode<T> aux = head;
        StringBuilder sb = new StringBuilder();
        
        while(aux.getDown() != null){
            //Agregamos todo lo de esa lista
            while(aux.getRight() != null && aux.getRight().getElement() != null){
                sb.append(aux.getRight().getElement());
                sb.append(" ");
                aux = aux.getRight();
            }
            sb.append("\n");
            aux = aux.getDown();
        }
        
        return sb.toString();
    }
    
    public String printSecondLevel(){
        SkipNode<T> aux = head.getDown();
        StringBuilder sb = new StringBuilder();
        
        if(aux != null){
            System.out.println("true");
            while(aux.getRight() != null && aux.getRight().getElement() != null){
                sb.append(aux.getRight().getElement());
                sb.append(" ");
                aux = aux.getRight();
            }
        }
        return sb.toString();
    }
    
    //Métodos que falta agregar
        //Liga arriba abajo
        //Liga izquierda derecha
    
    
    //Para borrar hay que verificar que tengamos logn listas o menos
    //Sino entonces tenemos que eliminar la lista de hasta arriba
    
    

}
