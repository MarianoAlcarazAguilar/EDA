package SkipLists;

import java.util.Objects;

public class SkipNode<T extends Comparable<T>>  {
    
    private T element;
    private SkipNode<T> left;
    private SkipNode<T> right;
    private SkipNode<T> up;
    private SkipNode<T> down;
    
    public SkipNode(){
        element = null;
        left = null;
        right = null;
        up = null;
        down = null;
    }
    
    public SkipNode(T element){
        this();
        this.element = element; 
    }

    public T getElement() {
        return element;
    }

    public SkipNode<T> getLeft() {
        return left;
    }

    public SkipNode<T> getRight() {
        return right;
    }

    public SkipNode<T> getUp() {
        return up;
    }

    public SkipNode<T> getDown() {
        return down;
    }

    public void setElement(T element) {
        this.element = element;
    }

    public void setLeft(SkipNode<T> left) {
        this.left = left;
    }

    public void setRight(SkipNode<T> right) {
        this.right = right;
    }

    public void setUp(SkipNode<T> up) {
        this.up = up;
    }

    public void setDown(SkipNode<T> down) {
        this.down = down;
    }
    
    public boolean isHead(){
        return left == null;
    }
    
    public boolean isTail(){
        return right == null;
    }
    
    public boolean hasDown(){
        return down != null;
    }
    
    public boolean hasUp(){
        return up != null;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SkipNode<?> other = (SkipNode<?>) obj;
        return Objects.equals(this.element, other.element);
    }
    
    
    
    
    
    
}
