package Tests;

import Algoritmos.Sort;
import TareaPeliculas.Pelicula;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class NoisyOrdering {
    
    private static Scanner x;
    private static Pelicula[] movies = new Pelicula[17770];
    
    
    private static void openFile(){
        
        try{
            x = new Scanner(new File("titles2.csv"));
        } catch (FileNotFoundException e){
            System.out.println("File not found");
        }
        
    }
    
    private static void closeFile(){
        x.close();
    }
    
    private static void uploadData(){
        int i = 0;
        while(x.hasNext()){
            String st = x.nextLine();
            String[] data = st.split(",");
            String mins = data[0];
            String year = data[1];
            String name = data[2];
            Integer aa = Integer.parseInt(mins);
            Integer bb = Integer.parseInt(year);
            Pelicula pelicula = new Pelicula(aa,bb,name);
            movies[i] = pelicula;
            i++;
        }
    }
    
    public static int countMovies(){
        openFile();
        int cont = 0;
        while(x.hasNextLine()){
            x.nextLine();
            cont++;
        }
        closeFile();
        return cont;
    }
    
    
    private static Pelicula[] randomArray(int size){
        Pelicula[] resp = new Pelicula[size];
        Sort.shuffle(movies);
        for(int i = 0; i < size; i++)
            resp[i] = movies[i];
        return resp;
    }
    
    
    private static int countSortedBlocks(Pelicula[] array){
        int totElem = array.length;
        int bloques = 1;
        int i = 0;
        while(i < totElem-1){
            if(array[i].correctCompareTo(array[i+1]) > 0){
                bloques++;
            }
            i++;
        }
        return bloques;
    }
    
    private static double avgBlocks(int[] array){
        double suma = 0.0;
        for(int i = 0; i < array.length; i++){
            suma += array[i];
        }
        return suma/array.length;
    }
    
    private static void createFile(String title, String text){
        try{
            try (PrintWriter pw = new PrintWriter(new File("C:\\Users\\Usuario\\Desktop\\TODO\\ITAM\\EDA\\Datos\\OrdenamientoRuidoso\\"+title+".csv"))) {
                pw.write(text);
                pw.close();
                System.out.println("Se ha creado el archivo " + title + ".csv");
            }
        }catch (FileNotFoundException e) {
            System.out.println("Something went wrong when writing file");
        }
    }
    

    public static void main(String[] args) {
        openFile();
        uploadData();
        closeFile();
        
        Pelicula[] datos;
        int n = 100;
        int sampleSize = 1000;
        int[] resSel = new int[n];
        int[] resIns = new int[n];
        int[] resBub = new int[n];
        int[] resQui = new int[n];
        int[] resMer = new int[n];
        int[] aux;
        double ax;
        String title = "noisyOrder3";
        Sort sort = new Sort();
        StringBuilder sb = new StringBuilder();
        
        sb.append("Algorithm");
        sb.append(",");
        sb.append("AvgBlocks");
        sb.append(",");
        sb.append("Element-Block-Ratio");
        sb.append("\n");
        
        //Selection Sort
        for(int i = 0; i < n; i++){
            datos = randomArray(sampleSize);
            sort.selection_sort(datos);
            resSel[i] = countSortedBlocks(datos);
        }
        
        aux = resSel;
        System.out.println("Resultados Selection Sort ");
        
        System.out.println("Total de elementos en el arreglo: " + sampleSize);
        for(int i = 0; i < n; i++){
            System.out.print(aux[i] + " ");
        }
        System.out.println("\nPromedio: " + avgBlocks(aux));
        
        System.out.println("Relación Elementos-Bloques: " + sampleSize/avgBlocks(aux));
        
        sb.append("SelectionSort");
        sb.append(",");
        sb.append(avgBlocks(aux));
        sb.append(",");
        ax = sampleSize/avgBlocks(aux);
        sb.append(ax);
        sb.append("\n");
        
        
        //Insertion Sort
        for(int i = 0; i < n; i++){
            datos = randomArray(sampleSize);
            sort.insertion_sort(datos);
            resIns[i] = countSortedBlocks(datos);
        }
        
        aux = resIns;
        System.out.println("\nResultados Insertion Sort ");
        System.out.println("Total de elementos en el arreglo: " + sampleSize);
        for(int i = 0; i < n; i++){
            System.out.print(aux[i] + " ");
        }
        System.out.println("\nPromedio: " + avgBlocks(aux));
        System.out.println("Relación Elementos-Bloques: " + sampleSize/avgBlocks(aux));
        
        sb.append("InsertionSort");
        sb.append(",");
        sb.append(avgBlocks(aux));
        sb.append(",");
        ax = sampleSize/avgBlocks(aux);
        sb.append(ax);
        sb.append("\n");
        
        //Bubble Sort
        for(int i = 0; i < n; i++){
            datos = randomArray(sampleSize);
            sort.bubble_sort(datos);
            resBub[i] = countSortedBlocks(datos);
        }
        
        aux = resBub;
        System.out.println("\nResultados Bubble Sort ");
        System.out.println("Total de elementos en el arreglo: " + sampleSize);
        for(int i = 0; i < n; i++){
            System.out.print(aux[i] + " ");
        }
        System.out.println("\nPromedio: " + avgBlocks(aux));
        System.out.println("Relación Elementos-Bloques: " + sampleSize/avgBlocks(aux));
        
        sb.append("BubbleSort");
        sb.append(",");
        sb.append(avgBlocks(aux));
        sb.append(",");
        ax = sampleSize/avgBlocks(aux);
        sb.append(ax);
        sb.append("\n");
        
        //Quick Sort
        for(int i = 0; i < n; i++){
            datos = randomArray(sampleSize);
            sort.quick_sort(datos);
            resQui[i] = countSortedBlocks(datos);
        }
        
        aux = resQui;
        System.out.println("\nResultados Quick Sort ");
        System.out.println("Total de elementos en el arreglo: " + sampleSize);
        for(int i = 0; i < n; i++){
            System.out.print(aux[i] + " ");
        }
        System.out.println("\nPromedio: " + avgBlocks(aux));
        System.out.println("Relación Elementos-Bloques: " + sampleSize/avgBlocks(aux));
        
        sb.append("QuickSort");
        sb.append(",");
        sb.append(avgBlocks(aux));
        sb.append(",");
        ax = sampleSize/avgBlocks(aux);
        sb.append(ax);
        sb.append("\n");
        
        //Merge Sort
        for(int i = 0; i < n; i++){
            datos = randomArray(sampleSize);
            sort.merge_sort(datos);
            resMer[i] = countSortedBlocks(datos);
        }
        
        aux = resMer;
        System.out.println("\nResultados Merge Sort ");
        System.out.println("Total de elementos en el arreglo: " + sampleSize);
        for(int i = 0; i < n; i++){
            System.out.print(aux[i] + " ");
        }
        System.out.println("\nPromedio: " + avgBlocks(aux));
        System.out.println("Relación Elementos-Bloques: " + sampleSize/avgBlocks(aux));
        
        sb.append("MergeSort");
        sb.append(",");
        sb.append(avgBlocks(aux));
        sb.append(",");
        ax = sampleSize/avgBlocks(aux);
        sb.append(ax);
        sb.append("\n");
        
        createFile(title, sb.toString());
    }
}
