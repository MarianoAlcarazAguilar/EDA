package Tests;

import Algoritmos.Sort;

public class PrimitivosTests {

    public static void main(String[] args) {
        
        Integer[] arrayInteger = {3,10,-8,2,40,-1,35,48,15,0};
        Sort quickSort = new Sort();
        Sort selectionSort = new Sort();
        Sort insertionSort = new Sort();
        Sort bubbleSort = new Sort();
        Sort mergeSort = new Sort();
        
        
        //SELECTION SORT
        System.out.println("-----------SELECTION SORT------------");
        System.out.println("Antes:");
        Sort.shuffle(arrayInteger);
        for (Integer array1 : arrayInteger){
            System.out.print(array1 + ", ");
        }
        
        selectionSort.selection_sort(arrayInteger);
        System.out.println("\nDespués:");
        for (Integer array1 : arrayInteger) {
            System.out.print(array1 + ", ");
        }
        
        System.out.println("\nComparaciones: " + selectionSort.comparisons + " Swaps: " + selectionSort.swaps);
        
        //INSERTION SORT
        System.out.println("\n\n");
        System.out.println("-----------INSERTION SORT------------");
        System.out.println("Antes:");
        Sort.shuffle(arrayInteger);
        for (Integer array1 : arrayInteger){
            System.out.print(array1 + ", ");
        }
        
        insertionSort.insertion_sort(arrayInteger);
        System.out.println("\nDespués:");
        for (Integer array1 : arrayInteger) {
            System.out.print(array1 + ", ");
        }
        
        System.out.println("\nComparaciones: " + insertionSort.comparisons + " Swaps: " + insertionSort.swaps);
        
        //BUBBBLE SORT
        System.out.println("\n\n");
        System.out.println("-----------BUBBLE SORT------------");
        System.out.println("Antes:");
        Sort.shuffle(arrayInteger);
        for (Integer array1 : arrayInteger){
            System.out.print(array1 + ", ");
        }
        
        bubbleSort.bubble_sort(arrayInteger);
        System.out.println("\nDespués:");
        for (Integer array1 : arrayInteger) {
            System.out.print(array1 + ", ");
        }
        
        System.out.println("\nComparaciones: " + bubbleSort.comparisons + " Swaps: " + bubbleSort.swaps);
        
        //QUICK SORT
        System.out.println("\n\n");
        Sort.shuffle(arrayInteger);
        System.out.println("-----------QUICK SORT------------");
        System.out.println("Antes:");
        for (Integer array1 : arrayInteger){
            System.out.print(array1 + ", ");
        }
        
        quickSort.quick_sort(arrayInteger);
        System.out.println("\nDespués:");
        for (Integer array1 : arrayInteger) {
            System.out.print(array1 + ", ");
        }
        
        System.out.println("\nComparaciones: " + quickSort.comparisons + " Swaps: " + quickSort.swaps);
        
        
        //MERGE SORT
        System.out.println("\n\n");
        Sort.shuffle(arrayInteger);
        System.out.println("-----------MERGE SORT------------");
        System.out.println("Antes:");
        for (Integer array1 : arrayInteger){
            System.out.print(array1 + ", ");
        }
        
        mergeSort.merge_sort(arrayInteger);
        System.out.println("\nDespués:");
        for (Integer array1 : arrayInteger) {
            System.out.print(array1 + ", ");
        }
        
        System.out.println("\nComparaciones: " + mergeSort.comparisons + " Swaps: " + mergeSort.swaps);
        
        
        
        
        
        
        
        
        
    }

}
