package TareaPeliculas;

import java.util.Random;

public class Pelicula implements Comparable{
    
    private Integer mins;
    private Integer year;
    private String name;
    private double failRate;

    public Pelicula() {
    }

    public Pelicula(int mins, int year, String name) {
        this.mins = mins;
        this.year = year;
        this.name = name;
        this.failRate = 0.03;
    }

    public Integer getMins() {
        return mins;
    }

    public Integer getYear() {
        return year;
    }

    public String getName() {
        return name;
    }
    
    public double getFailRate(){
        return failRate;
    }
    
    public void setFailRate(double failRate){
        this.failRate = failRate;
    }

    public void setMins(int mins) {
        this.mins = mins;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Nombre: " + this.name + ", Año: " + this.year + ", Minutos: " + this.mins;
    }
    
    
    public int correctCompareTo(Object o) {
        Pelicula other = (Pelicula)o;
        if(this.year > other.getYear()){
            return 1;
        } else {
            if (this.year < other.getYear()){
                return -1;
            } else {
                if(this.mins > other.getMins())
                    return 1;
                else {
                    if(this.mins < other.getMins())
                        return -1;
                    else return 0;
                } 
            }
        }
    }
  
    /**
     * Este CompareTo se equivoca el 10% de las veces.
     * @param o
     * @return 
     */
    public int compareTo(Object o){
        Pelicula other = (Pelicula)o;
        Random r = new Random();
        int aux = r.nextInt(101);
        int answer;
        if(r.nextDouble() > failRate){
            if(this.year > other.getYear()){
            answer = 1;
            } else {
                if (this.year < other.getYear()){
                    answer = -1;
                } else {
                    if(this.mins > other.getMins())
                        answer = 1;
                    else {
                        if(this.mins < other.getMins())
                            answer = -1;
                        else
                            answer = 0;
                    } 
                }
            }
        } else {
            if(this.year > other.getYear()){
            answer = -1;
            } else {
                if (this.year < other.getYear()){
                    answer = 1;
                } else {
                    if(this.mins > other.getMins())
                        answer = -1;
                    else {
                        if(this.mins < other.getMins())
                            answer = 1;
                        else
                            answer = 0;
                    } 
                }
            }
        }
        return answer;        
    }
    
    
    
    

}
