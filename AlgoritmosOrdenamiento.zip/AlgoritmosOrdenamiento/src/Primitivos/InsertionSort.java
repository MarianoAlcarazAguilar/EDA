package Primitivos;

public class InsertionSort {
    
    /**
     * Método auxiliar
     * @param array
     * @param total
     * @param searched
     * @return 
     */
    private static int binarySearch(int[] array, int total, int searched){
        int izq, der, cen;
        izq = 0;
        der = total-1;
        cen = der/2;
        while(izq <= der && array[cen] != searched){
            if(searched > array[cen])
                izq = cen +1;
            else
                der = cen-1;
            cen = (izq + der)/2;
        }
        if(izq > der)
            cen = -(izq+1);
        return cen;
    }
    
    /**
     * Método auxiliar
     * @param array
     * @param total
     * @param pos 
     */
    private static void recorreDerecha(int[] array, int total, int pos){
        for(int i = total; i > pos; i--)
            array[i] = array[i-1];
    }
    
   
   
    /**Es un método auxiliar para ordenar todo
     * 
     * @param array
     * @param elementPos 
     */
    private static void ordenaSubArray(int[] array, int elementPos){
        if(array == null || elementPos < 0 || elementPos > array.length)
            throw new RuntimeException("Array null or elementPos out of boundries in ordenaSubArray");
        
        int pos = binarySearch(array, elementPos, array[elementPos]);
        int aux = array[elementPos];
        if(pos<0){
            pos = -1*pos-1;
            recorreDerecha(array, elementPos, pos);
            array[pos] = aux;
        }
        
        
        
    }
    
    /**Este método ordena utilizando el algoritmo de InsertionSort
     * 
     * @param array 
     */
    public static void ordenaInsertion(int[] array){
        if(array == null)
            throw new RuntimeException("Array is null in ordenaInsertion");
        
        for(int i = 0; i < array.length; i++){
            ordenaSubArray(array, i);
        } 
    }
    
    private static void swap(int[] array, int a, int b){
        int aux = array[b];
        array[b] = array[a];
        array[a] = aux;
    }
    
    /**
     * Este método es la forma correcta de implementar este ordenamiento.
     * Se va comparando el elemento con el anterior y se va acomodando
     * @param array 
     */
    public static void ordena_insertion(int[] array){
        if(array == null)
            throw new RuntimeException("Array in ordena_insertion is null");
        
        int i = 1;
        while(i < array.length){
            if(array[i] < array[i-1]){
                swap(array, i, i-1);
            } else
                i++;
        }
        
        
    }
    
    /**
     * Método final. Es O(n^2)
     * @param array 
     */
    public static void order_insertion(int[] array){
        if(array == null)
            throw new RuntimeException("Array in order_insertion is null");
        
        int i, j, aux;
        
        for(i = 1; i < array.length; i++){
            j = i;
            while(j > 0 && array[j] < array[j-1]){
                swap(array,j,j-1);
                j--;
            }
        }
    }

}
