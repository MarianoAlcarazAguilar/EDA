package Primitivos;

public class BubbleSort {
    
    private static void swap(int[] array, int a, int b){
        int aux = array[b];
        array[b] = array[a];
        array[a] = aux;
    }
    
    /**
     * Falta llenar
     * @param array 
     */
    public static void buuble_sort(int[] array){
        if(array == null)
            throw new RuntimeException("Array in bubble_sort is null");
        
        
        for(int i = 0; i < array.length; i++){
            int j = array.length - i;
            while(i < j){
                if(array[i] < 0)
                    swap(array, i,j); 
                j++;
            }
        }
    }
    
    /**
     * Este método es de tipo O(n^2)
     * @param array 
     */
    public static void bubble_sort(int[] array){
        if(array == null)
            throw new RuntimeException("Array in bubble_sort is null");
        
        for(int j = array.length-1; j > 0; j--){
            for(int i = 0; i < j; i++){
                if(array[i] > array[i+1]){
                    swap(array,i,i+1);
                }
            }
        }
    }

}
