package Primitivos;

/**
 * Esta clase es para ordenar arreglos de int.
 * @author Usuario
 */
public class SelectionSort{
    
    /**
     * Método para hacer cambio de dos posiciones en un arreglo.
     * @param array
     * @param das
     * @param hier 
     */
    public static void swap(int[] array, int das, int hier){
        if(array == null || das < 0 || hier < 0 || das > array.length || hier > array.length)
            throw new RuntimeException("Array nulo o fuera de límites a mover");
        
        int aux = array[hier];
        array[hier] = array[das];
        array[das] = aux;
    }
    
    
    /**
     * Método para encontrar la posición del mínimo usando selección directa
     * @param array
     * @param startPos
     * @return 
     */
    public static int findPosMin(int[] array, int startPos){
        if(array == null || startPos < 0 || startPos > array.length)
            throw new RuntimeException("Array is null in findPosMin or startPos out of boudries");
        
        int pos = startPos;
        for(int i = startPos; i < array.length; i++){
            if(array[i] < array[pos])
                pos = i;
        }
        return pos;
    }
   
    
    /**
     * Método de selección directa O(n^2)
     * @param array 
     */
    public static void ordenaSeleccionDirecta(int[] array){
        if(array == null)
            throw new RuntimeException("Array is null in seleccionDirecta");
        
        int min;
        for(int i = 0; i < array.length; i++){
            min = findPosMin(array,i);
            swap(array,i,min);
        }
        
    }
    

}
