package Primitivos;

public class QuickSort {
    
    /**
     * Método auxiliar para cambiar la posición de dos elementos en un arreglo.
     * @param array
     * @param a
     * @param b 
     */
    private static void swap(int[] array, int a, int b){
        int aux = array[b];
        array[b] = array[a];
        array[a] = aux;
    }
    
    /**
     * Este método regresa la posición adecuada del primer elemento.
     * Pone todos los elementos menores a la izquierda y los más grandes a la derecha.
     * MAX SE INCLUYE.
     * @param array
     * @param min
     * @param max
     * @return 
     */
    private static int partition(int[] array, int min, int max){
        if(array == null)
            throw new RuntimeException("Array in partition is null");
        
        int posMin = min;
        int i, j;
        
        i = min + 1;
        while(i <= max){
            if(array[i] > array[i-1]){
                swap(array,i,max);
                max--;
            } else {
                swap(array,i, i-1);
                i++;
                posMin++;
            }
        }
        return posMin;
    }
    
    /**
     * Este método es O(2log(n)?)
     * @param array
     * @param min
     * @param max 
     */
    private static void quick_sort(int[] array, int min, int max){
        if(min >= max)
            return;
        
        int pos_pivote = partition(array, min, max); //particion regresa la posición donde dejó al primer elemento        
        quick_sort(array, min, pos_pivote-1);
        quick_sort(array, pos_pivote+1, max);
    }
    
    /**
     * Método auxiliar que llama al método recursivo.
     * @param array 
     */
    public static void quick_sort(int[] array){
        if(array == null)
            throw new RuntimeException("Array in quick_sort is null");
        
        quick_sort(array,0,array.length-1);
    } 
    
    
}
